﻿using System;
using CalendarSystem.Controller;
using CalendarSystem.DataStorage;
using CalendarSystem.Model;

namespace CalendarSystem.View
{
    /// <summary>
    /// The login view is the view which is prompted to the user first.
    /// It contains two textboxes and a login button.
    /// </summary>
    class LoginView : IViews
    {
        public LoginView()
        {
            
        }

        private void okButton()
        {
           
        }

        public void Show()
        {
            throw new NotImplementedException();
        }

        public void Hide()
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }
    }
}
