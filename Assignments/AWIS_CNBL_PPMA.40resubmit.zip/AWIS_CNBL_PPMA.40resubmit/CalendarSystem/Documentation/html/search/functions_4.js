var searchData=
[
  ['notifyobservers',['NotifyObservers',['../class_calendar_system_1_1_data_storage_1_1_database_storage.html#a9dde52dd67fc234b5f4ed217801968af',1,'CalendarSystem.DataStorage.DatabaseStorage.NotifyObservers()'],['../class_calendar_system_1_1_data_storage_1_1_fake_storage.html#ad141dac914a11365efa50b8bf1bcc80d',1,'CalendarSystem.DataStorage.FakeStorage.NotifyObservers()'],['../interface_calendar_system_1_1_model_1_1_i_observable.html#aee5d17758abde1cd470266ede5fab0c1',1,'CalendarSystem.Model.IObservable.NotifyObservers()']]]
];
