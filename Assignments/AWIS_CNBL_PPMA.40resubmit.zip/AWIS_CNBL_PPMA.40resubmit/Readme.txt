Assignment by Anders Wind(awis), Christopher Blundell(cnbl) and Pierre Mandas(ppma).

THE RESUBMISSION OF ASSIGNMENT 40

The documents for Assignment 40 are the PDF's AWIS_CNBL_PPMA.RAD (nothing new here) and AWIS_CNBL_PPMA.SDD

The Architectual Prototype for the CalendarSystem is the Microsoft Visual Studio Solution. The source code is located in the project folder 'CalendarSystem'.
.exe files for the projects can be found in the subfolder 'projectname\bin\Debug'

The Dependency diagram can be found in the subfolder 'ModelingProject1'.