var searchData=
[
  ['tag',['Tag',['../class_calendar_system_1_1_model_1_1_tag.html',1,'CalendarSystem::Model']]]
];
