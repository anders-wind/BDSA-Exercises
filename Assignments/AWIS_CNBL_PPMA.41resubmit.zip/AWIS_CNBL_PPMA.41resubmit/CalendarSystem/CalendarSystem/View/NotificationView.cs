﻿namespace CalendarSystem.View
{
    /// <summary>
    /// A class that visually represents an notification object, or the creation thereof.
    /// </summary>
    class NotificationView : IViews
    {
        public void Show()
        {
            throw new System.NotImplementedException();
        }

        public void Hide()
        {
            throw new System.NotImplementedException();
        }

        public void Clear()
        {
            throw new System.NotImplementedException();
        }
    }
}
