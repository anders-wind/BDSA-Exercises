Assignment by Anders Wind(awis), Christopher Blundell(cnbl) and Pierre Mandas(ppma).

Assignment 41: (RAD) is the PDF AWIS_CNBL_PPMA.41.RAD (nothing new). (SDD) is the PDF AWIS_CNBL_PPMA.41.SDD

The architectural part of the assignment is the Microsoft Visual Studio Solution. The source code is located in the project folder 'CalendarSystem'.
.exe files for the projects can be found in the subfolder 'projectname\bin\Debug'

We have three proxy patterns: StorageProxy, EventProxy and NotificationProxy.
We have implemented the invariants in classes Event, Notification and DatabaseStorageImplementor.
We have implemented the pre- and postconditions in the DatabaseStorageImplementor.