Assignment by Anders Wind(awis), Christopher Blundell(cnbl) and Pierre Mandas(ppma).

37.1 is the PDF AWIS_CNBL_PPMA.37

37.2 is the Microsoft Visual Studio Solution. The source code is located in the project folder 'TextFileReader'.
.exe files for the projects can be found in the subfolder 'projectname\bin\Debug'
Documentation for the TextFileReader project can be found in the PDF: AWIS_CNBL_PPMA_TextSearcherDoc or in 'projectname\doc\