var searchData=
[
  ['textsearcher',['TextSearcher',['../class_text_file_reader_project_1_1_text_searcher.html',1,'TextFileReaderProject']]],
  ['textsearchertests',['TextSearcherTests',['../class_text_file_reader_project_1_1_text_searcher_tests.html',1,'TextFileReaderProject']]]
];
