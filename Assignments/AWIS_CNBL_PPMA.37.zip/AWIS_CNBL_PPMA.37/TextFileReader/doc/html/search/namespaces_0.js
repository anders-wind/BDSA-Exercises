var searchData=
[
  ['textfilereaderproject',['TextFileReaderProject',['../namespace_text_file_reader_project.html',1,'']]]
];
