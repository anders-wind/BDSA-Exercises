Assignment by Anders Wind(awis), Christopher Blundell(cnbl) and Pierre Mandas(ppma).

36.1 is the pdf.

36.2 35.2 is the Microsoft Visual Studio Solution. The source code is located in the project folder 'ReversePolishCalculator'.
.exe files for the projects can be found in the subfolder 'projectname\bin\Debug'