/**
IGNORE FOR NOW - ONLY C# SUBMITTED

Assignment by Anders Wind(awis), Christopher Blundell(cnbl) and Pierre Mandas(ppma).

Assignment 43: (RAD) is the PDF AWIS_CNBL_PPMA.41.RAD (nothing new). (SDD) is the PDF AWIS_CNBL_PPMA.41.SDD

The architectural part of the assignment is the Microsoft Visual Studio Solution. The source code is located in the project folder 'CalendarSystem'.
.exe files for the projects can be found in the subfolder 'projectname\bin\Debug'

**/

The C# part of the assignment is the Microsoft Visual Studio Solution. The source code is located in the project folder 'Northwind_Solution'.
.exe files for the projects can be found in the subfolder '(Northwind/NorthwindApplication/NorthwindApplications.tests)\bin\Debug'