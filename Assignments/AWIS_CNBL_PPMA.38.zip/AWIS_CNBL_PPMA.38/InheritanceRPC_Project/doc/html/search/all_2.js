var searchData=
[
  ['execute',['Execute',['../class_inheritance_r_p_c___project_1_1_binary_operation.html#a9c344c45450b8496e1f6537b1a467a6c',1,'InheritanceRPC_Project.BinaryOperation.Execute()'],['../class_inheritance_r_p_c___project_1_1_unary_operation.html#af5f32626af010e981e3e08aab753a61c',1,'InheritanceRPC_Project.UnaryOperation.Execute()']]]
];
