var searchData=
[
  ['unaryoperation',['UnaryOperation',['../class_inheritance_r_p_c___project_1_1_unary_operation.html',1,'InheritanceRPC_Project']]]
];
