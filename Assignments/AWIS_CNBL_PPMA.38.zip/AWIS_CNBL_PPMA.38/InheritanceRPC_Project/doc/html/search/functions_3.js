var searchData=
[
  ['inheritancerpc',['InheritanceRPC',['../class_inheritance_r_p_c___project_1_1_inheritance_r_p_c.html#ad34c70442f6f3696e800c3937f5bfd20',1,'InheritanceRPC_Project::InheritanceRPC']]]
];
