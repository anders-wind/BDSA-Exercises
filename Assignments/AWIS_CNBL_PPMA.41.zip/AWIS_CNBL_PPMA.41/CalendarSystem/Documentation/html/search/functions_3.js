var searchData=
[
  ['loginauthentication',['loginAuthentication',['../class_calendar_system_1_1_data_storage_1_1_database_storage.html#a3c7ccd413ae0f0d4684cf1b1998cddcd',1,'CalendarSystem.DataStorage.DatabaseStorage.loginAuthentication()'],['../class_calendar_system_1_1_data_storage_1_1_fake_storage.html#a589c203e56e50f0e71a1d202f7411a2f',1,'CalendarSystem.DataStorage.FakeStorage.loginAuthentication()'],['../interface_calendar_system_1_1_data_storage_1_1_i_storage.html#a7818cf23c7f6dfca608c175d70558aa6',1,'CalendarSystem.DataStorage.IStorage.loginAuthentication()']]]
];
