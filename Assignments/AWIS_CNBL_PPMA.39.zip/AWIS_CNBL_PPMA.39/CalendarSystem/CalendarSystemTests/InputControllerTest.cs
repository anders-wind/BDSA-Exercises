﻿using System;
using CalendarSystem.Controller;
using NUnit.Framework;

namespace CalendarSystemTests
{
    [TestFixture]
    public class InputControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void placeholder()
        {
        }
    }
}
