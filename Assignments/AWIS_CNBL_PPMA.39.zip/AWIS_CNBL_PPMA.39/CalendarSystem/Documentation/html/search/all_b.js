var searchData=
[
  ['saveevent',['SaveEvent',['../class_calendar_system_1_1_data_storage_1_1_database_storage.html#ae4e6526f9d99e4a01b75a591a15fba9c',1,'CalendarSystem.DataStorage.DatabaseStorage.SaveEvent()'],['../class_calendar_system_1_1_data_storage_1_1_fake_storage.html#ac59fb43db4eb01c5b6153c7919608313',1,'CalendarSystem.DataStorage.FakeStorage.SaveEvent()'],['../interface_calendar_system_1_1_data_storage_1_1_i_storage.html#a041366475064bd7008e0546ac8d5d148',1,'CalendarSystem.DataStorage.IStorage.SaveEvent()']]],
  ['startmainview',['startMainView',['../class_calendar_system_1_1_controller_1_1_view_controller.html#a70e4c5e8dd89b0dbd3f8da0d39ab652b',1,'CalendarSystem::Controller::ViewController']]]
];
