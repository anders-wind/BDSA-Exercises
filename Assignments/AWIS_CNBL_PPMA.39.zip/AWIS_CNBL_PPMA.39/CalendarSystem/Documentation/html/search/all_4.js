var searchData=
[
  ['fakestorage',['FakeStorage',['../class_calendar_system_1_1_data_storage_1_1_fake_storage.html',1,'CalendarSystem::DataStorage']]]
];
