﻿using System;
using System.Drawing;

namespace CalendarSystem.Model
{
    /// <summary>
    /// Implementation is unclear for now
    /// </summary>
    public class Tag
    {
        enum tags
        {
            WORK,
            PRIVATE,
        }

        public void createTags(string newTag, Color newColor) // Skal muligvis placeres et andet sted (en controller?)
        {
            throw new NotImplementedException();
        }
    }
}
