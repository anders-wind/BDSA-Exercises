﻿namespace CalendarSystem.View
{
    /// <summary>
    /// A class that visually represents an notification object, or the creation thereof.
    /// </summary>
    class NotificationView
    {
    }
}
