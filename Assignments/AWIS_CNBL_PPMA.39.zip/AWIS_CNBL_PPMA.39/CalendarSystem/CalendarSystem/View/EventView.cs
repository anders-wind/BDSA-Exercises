﻿namespace CalendarSystem.View
{
    /// <summary>
    /// A class that visually represents an event object, or the creation thereof.
    /// </summary>
    class EventView
    {
    }
}
