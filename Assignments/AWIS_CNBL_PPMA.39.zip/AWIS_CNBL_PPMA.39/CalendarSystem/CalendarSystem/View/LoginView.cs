﻿using System;
using CalendarSystem.Controller;
using CalendarSystem.DataStorage;
using CalendarSystem.Model;

namespace CalendarSystem.View
{
    /// <summary>
    /// The login view is the view which is prompted to the user first.
    /// It contains two textboxes and a login button.
    /// </summary>
    class LoginView
    {
        public LoginView()
        {
            
        }

        private void okButton()
        {
           
        }
    }
}
